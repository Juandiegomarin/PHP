<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 4</title>
</head>
<body>

<?php

$arr[]="Pedro";
$arr[]="Ana";
$arr[]=1;
$arr[]=34;


print_r($arr);


?>
    
</body>
</html>